#!/bin/sh
set -eu

: "${output_dir:?missing output_dir}"
: "${fastqs:?missing fastqs}"

quality="${quality:-20}"
phred_mode="${phred_mode:-auto}"
adapter="${adapter:-}"
stringency="${stringency:-1}"
length="${length:-20}"
max_length="${max_length:-0}"
error_rate="${error_rate:-0.1}"
paired="${paired:-false}"
retain_unpaired="${retain_unpaired:-false}"
trim_n="${trim_n:-false}"
gzip_output="${gzip_output:-true}"
threads="${threads:-4}"

mkdir -p "$output_dir"

echo "[INFO] Trim Galore QC starting..."
echo "[INFO] Input files: $fastqs"
echo "[INFO] Output directory: $output_dir"

build_trim_galore_cmd() {
  cmd="trim_galore"
  
  cmd="$cmd -q $quality"
  cmd="$cmd --length $length"
  
  if [ "$max_length" -gt 0 ]; then
    cmd="$cmd --max_length $max_length"
  fi
  
  cmd="$cmd -e $error_rate"
  cmd="$cmd --stringency $stringency"
  cmd="$cmd -j $threads"
  
  if [ "$phred_mode" = "phred33" ]; then
    cmd="$cmd --phred33"
  elif [ "$phred_mode" = "phred64" ]; then
    cmd="$cmd --phred64"
  fi
  
  if [ -n "$adapter" ]; then
    cmd="$cmd -a $adapter"
  fi
  
  if [ "$paired" = "true" ]; then
    cmd="$cmd --paired"
  fi
  
  if [ "$retain_unpaired" = "true" ]; then
    cmd="$cmd --retain_unpaired"
  fi
  
  if [ "$trim_n" = "true" ]; then
    cmd="$cmd --trim-n"
  fi
  
  if [ "$gzip_output" = "true" ]; then
    cmd="$cmd --gzip"
  else
    cmd="$cmd --dont_gzip"
  fi
  
  cmd="$cmd --fastqc"
  cmd="$cmd -o $output_dir"
  
  echo "$cmd"
}

trim_galore_cmd=$(build_trim_galore_cmd)
echo "[INFO] Command: $trim_galore_cmd"

eval "$trim_galore_cmd" $fastqs 2>&1

exit_code=$?

if [ $exit_code -eq 0 ]; then
  echo "[SUCCESS] Trim Galore completed successfully"
  echo "[OUTPUT] Files saved to: $output_dir"
else
  echo "[ERROR] Trim Galore failed with exit code: $exit_code"
  exit $exit_code
fi
