#!/usr/bin/env python3
"""
Remove rows where all samples have zero expression from expression matrices.
Processes: gene_*.csv and transcripts_*.csv files
"""
import csv
import os
import sys

if len(sys.argv) < 2:
    print("Usage: remove_zero_rows.py <output_dir>")
    sys.exit(1)

out_dir = sys.argv[1]

matrix_files = []
for pattern in ['gene_counts.csv', 'gene_fpkm.csv', 'gene_tpm.csv', 
                'transcripts_counts.csv', 'transcripts_fpkm.csv', 'transcripts_tpm.csv']:
    filepath = os.path.join(out_dir, pattern)
    if os.path.exists(filepath):
        matrix_files.append(filepath)

if not matrix_files:
    print('[PrimiGenius] Warning: No matrix files found')
    sys.exit(0)

print('[PrimiGenius] Removing all-zero rows from {} matrices...'.format(len(matrix_files)))

total_removed, total_kept = 0, 0

for fp in matrix_files:
    fn = os.path.basename(fp)
    with open(fp, 'r', newline='') as f:
        reader = csv.reader(f)
        header = next(reader)
        rows = list(reader)
    
    if len(header) <= 2:
        print('[PrimiGenius] {}: No sample columns, skipping'.format(fn))
        continue
    
    kept, removed = [], 0
    for row in rows:
        if not row or len(row) < 2:
            removed += 1
            continue
        
        sample_vals = row[2:] if len(row) > 2 else []
        has_nonzero = False
        for v in sample_vals:
            try:
                if float(v) != 0:
                    has_nonzero = True
                    break
            except:
                has_nonzero = True
                break
        
        if has_nonzero:
            kept.append(row)
        else:
            removed += 1
    
    with open(fp, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(kept)
    
    total_removed += removed
    total_kept += len(kept)
    print('[PrimiGenius] {}: removed {} all-zero rows, kept {} rows'.format(fn, removed, len(kept)))

print('[PrimiGenius] Summary: removed {} all-zero rows, kept {} rows across all matrices'.format(total_removed, total_kept))
