#!/usr/bin/env python3
import csv
import os
import sys
import re
from collections import defaultdict, OrderedDict

if len(sys.argv) < 3:
    print("Usage: merge_abund_matrices.py <sample_list_file> <output_dir>")
    sys.exit(1)

sample_list_file = sys.argv[1]
out_dir = sys.argv[2]

samples = []
with open(sample_list_file, 'r') as f:
    for line in f:
        if line.strip() and not line.startswith('#'):
            parts = line.strip().split('\t')
            if len(parts) == 2:
                samples.append((parts[0], parts[1]))

if not samples:
    print('[PrimiGenius] Error: No samples found')
    sys.exit(1)

print('[PrimiGenius] Merging {} samples...'.format(len(samples)))

RE_FPKM = re.compile(r'FPKM "([^"]+)"')
RE_TPM = re.compile(r'TPM "([^"]+)"')

gene_fpkm = defaultdict(OrderedDict)
gene_tpm = defaultdict(OrderedDict)
trans_fpkm = defaultdict(OrderedDict)
trans_tpm = defaultdict(OrderedDict)
sample_names = []

for sname, gtf_path in samples:
    sample_names.append(sname)

    abund_file = os.path.join(os.path.dirname(gtf_path), sname+'.gene_abund.tab')
    if os.path.exists(abund_file):
        with open(abund_file) as f:
            reader = csv.DictReader(f, delimiter='\t')
            for row in reader:
                gene_id = row.get('Gene ID', row.get('gene_id', ''))
                if not gene_id:
                    continue
                try:
                    gene_fpkm[gene_id][sname] = float(row.get('FPKM', 0))
                except (ValueError, TypeError):
                    gene_fpkm[gene_id][sname] = 0.0
                try:
                    gene_tpm[gene_id][sname] = float(row.get('TPM', 0))
                except (ValueError, TypeError):
                    gene_tpm[gene_id][sname] = 0.0
    else:
        print('[PrimiGenius] Warning: {} not found'.format(abund_file))

    if os.path.exists(gtf_path):
        with open(gtf_path) as f:
            for line in f:
                if line.startswith('#'):
                    continue
                fields = line.strip().split('\t')
                if len(fields) < 9:
                    continue
                if fields[2] != 'transcript':
                    continue
                attrs = fields[8]
                tid_match = re.search(r'transcript_id "([^"]+)"', attrs)
                if not tid_match:
                    continue
                tid = tid_match.group(1)
                fpkm_match = RE_FPKM.search(attrs)
                tpm_match = RE_TPM.search(attrs)
                try:
                    trans_fpkm[tid][sname] = float(fpkm_match.group(1)) if fpkm_match else 0.0
                except (ValueError, TypeError):
                    trans_fpkm[tid][sname] = 0.0
                try:
                    trans_tpm[tid][sname] = float(tpm_match.group(1)) if tpm_match else 0.0
                except (ValueError, TypeError):
                    trans_tpm[tid][sname] = 0.0
    else:
        print('[PrimiGenius] Warning: {} not found'.format(gtf_path))

if not gene_fpkm and not trans_fpkm:
    print('[PrimiGenius] Error: No data found')
    sys.exit(1)

print('[PrimiGenius] Found {} genes and {} transcripts across {} samples'.format(
    len(gene_fpkm), len(trans_fpkm), len(sample_names)))

def write_matrix(fp, data, sample_list):
    with open(fp, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['gene_id'] + sample_list)
        for gid in sorted(data.keys()):
            row = [gid] + [round(data[gid].get(s, 0), 4) for s in sample_list]
            w.writerow(row)
    print('[PrimiGenius] Generated: {}'.format(os.path.basename(fp)))

write_matrix(os.path.join(out_dir, 'gene_fpkm.csv'), gene_fpkm, sample_names)
write_matrix(os.path.join(out_dir, 'gene_tpm.csv'), gene_tpm, sample_names)
write_matrix(os.path.join(out_dir, 'transcripts_fpkm.csv'), trans_fpkm, sample_names)
write_matrix(os.path.join(out_dir, 'transcripts_tpm.csv'), trans_tpm, sample_names)

print('[PrimiGenius] Expression matrices generated successfully!')
